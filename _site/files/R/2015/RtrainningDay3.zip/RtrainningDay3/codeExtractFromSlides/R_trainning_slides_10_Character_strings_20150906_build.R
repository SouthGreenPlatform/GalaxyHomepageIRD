## ----setup, include = FALSE, cache = FALSE-------------------------------
knitr::opts_chunk$set(error = TRUE, collapse = TRUE)

## ------------------------------------------------------------------------
mean == "mean"
class(mean)
class("mean")
"The 'R' project for statistical computing" != 'The "R" project for statistical computing'

## ---- eval=FALSE---------------------------------------------------------
## a <- "" # empty string
## b <- character(0) # empty character vector

## ------------------------------------------------------------------------
month.name[1:4]
length(month.name)
nchar(month.name)

## ---- collapse=TRUE------------------------------------------------------
chartr("u", "o", "union") # One characer is substituted
chartr(old = "ao", new = "A0", "This is a boring string") # Several characters can be is substituted
crazy = c("Here's to the crazy ones", "The misfits", "The rebels") # It is vectorized
chartr("aei", "#!?", crazy)
chartr("a-c", "D-F", letters[1:8]) # One can use ranges of characters

## ------------------------------------------------------------------------
casefold("aLL ChaRacterS in LoweR caSe")
casefold("All ChaRacterS in Upper Case", upper = TRUE)

## ---- collapse=TRUE------------------------------------------------------
paste("la", "maison", sep = " ") # basic concatenation, separator is a space
# Vectorized concatenation. Note that numeric vectors are converted to character.
paste("Section", 1:3, sep = "-")
paste("Section", 1:3, LETTERS[1:4], sep = "-") # Rules of recycling apply
paste("Section", 1:3, LETTERS[1:4], sep = "-", collapse = " & ") # Collapse everything to a single string
paste("Section", rep(1:3, each = 5), 1:5, sep = "-") # What is this doing!?


## ------------------------------------------------------------------------
sprintf(fmt = "The number pi = %f", pi)

## ------------------------------------------------------------------------
sprintf("The number pi = %E", pi) # scientific notation
sprintf("The number pi = %.2f %s", pi, c(". Yes ?", "or not?")) # specify precision. concatenate with text
sprintf("This is %-8s justification of text", "LEFT") # Also fixing field width to 8 characters.
sprintf("This is %8s justification of text", "RIGHT")


## ------------------------------------------------------------------------
diceResult <- 4
cat("The dice result is: ", diceResult, "!\nTry again.", sep = "")
cat("Long strings can", "be displayed over", "several lines using",
    "the fill= argument.", fill = 40)

## ------------------------------------------------------------------------
howRU <- function(x) {
  message("Will first check the type of the argument.")
  if (!is.logical(x)) {stop("Argument must be either 'TRUE' or 'FALSE'.\n")} # asserting argument type
  if (x) cat("I am fine, thank you!\n") else warning("I don't feel so good.\n") # issue a warning if feel sick
  cat("Good bye")
}
howRU("bof") # Trows an error: execution alted
howRU(TRUE) # prints something to stdout
howRU(FALSE) # warns you that something is unusual

## ------------------------------------------------------------------------
# extract based on a range of positions
substring(text = "abcdef", first = 2, last = 4)

# vectorized extraction
substring("abcdef", first = 1:4, last = 4:5) # the 'x' and 'last' vectors are recycled

# replacing portions of strings with the assignment operator
x = c("may", "the", "force", "be", "with", "you")
substring(x, 2, 2) <- "#"
x

# everything is a vector...
s <- c("more", "emotions", "are", "better", "than", "less")
substring(s, 1:3, 2:4) <- c(" ", "zzz")
s


## ------------------------------------------------------------------------
# What strings are email adresses?
s <- c("object@attribute", "Rstudio", maintainer("base"))
# The litteral approach
grep(pattern = "@", x = s, value = TRUE)
# Accurate with a more specifc pattern
myPat <- "([a-z0-9_\\.-]+)@([\\da-z\\.-]+)\\.([a-z\\.]{2,6})"
grep(pattern = myPat, x = s, value = TRUE)

## ------------------------------------------------------------------------
s <- c("tobacco pipe (hazardous!)", "pile of junk", "directory of files")
grepl("pi", s)

## ------------------------------------------------------------------------
grep("(", s, value = TRUE) # parentheses create capturing groups
grep("\\(", s, value = TRUE) # escape special meanning with DOUBLE backslash

## ------------------------------------------------------------------------
m <- regexpr(pattern = "pi[pl]e", text = s) # brakets define a character set
m
regmatches(x = s, m = m, invert = FALSE)

## ------------------------------------------------------------------------
sub(pattern = "pi[pl]e", replacement = "cigarette", x = s)
gsub("\\d", "_", "1789, the revolution") # global substitution of digits

## ------------------------------------------------------------------------
# Often used to get the words of a sentence
s <- c("Killian! I'll be back!",
"You cannot teach a man anything; you can only help him find it within himself – Galileo")
words <- strsplit(x = s, split = " ")
words # the returned object is a list of vectors

# It can be flattened
unlist(words)[1:10]

# It can be used in a `apply` construct
sapply(words, length) # number of words in the sentense


## ----ANS01, collapse=TRUE------------------------------------------------
cat(lab1 <- paste("S", 1:12, sep = "_"))
cat(lab2 <- sprintf("S_%02i",  1:12))
sort(lab1)
sort(lab2)

## ----ANS02---------------------------------------------------------------
s <- "saucisson sec"
## 1 ## The brutal way {.build}
# Break down string to a vector of single characters
vectOfSingleChar <- substring(s, 1:nchar(s), 1:nchar(s)) # First solution
vectOfSingleChar <- unlist(strsplit(s, split = "")) # Second, more 'elegant' solution

# Find indexes of vector elements corresponding to "s"
which(vectOfSingleChar == "s")

## 2 ## Using regular expressions {.build}
gregexpr("s", s)

## ----ANS03---------------------------------------------------------------
simpleCap <- function(s) {
spls <- strsplit(s, " ")[[1]]

paste(toupper(substring(spls, 1, 1)),
      substring(spls, 2),
      sep = "", collapse = " ")
}
simpleCap("This is a sentence.")

## ----ANS04---------------------------------------------------------------
dose <- seq(60, 80, 10)
exposureTime <- c(100, 200)
sex <- c("Male","Female")

## ----ANS05---------------------------------------------------------------
mdf <- expand.grid(dose, exposureTime, sex)
apply(X = mdf, MARGIN = 1, FUN = paste, collapse = "-")

## ----ANS06---------------------------------------------------------------
f <- "/media/cunnac/DONNEES/CUNNAC/Lab-Related/Communications/Teaching/R_trainning_module/filesToBringToTrainning/englishWords.txt"
words <- readLines(f)
wl <- nchar(words)
max(wl)
words[wl == max(wl)] # longest word
mwl <- median(wl) # median of word length
mwl

tionWords <- grep("tion$", words, value = TRUE) # words ending with "tion"
tionWords[1:10]
length(tionWords)

## ----ANS07, eval= FALSE--------------------------------------------------
## # First have a sense of the distribution of letters in "real" words:
## letterDistris <- lapply(strsplit(words, ""), FUN = function(x) {
##   x <- factor(x, levels = letters)
##   as.matrix(table(x))
##   }
## )
## 
## letterFreq <- prop.table(table(factor(unlist(strsplit(paste(words, collapse = ""), "")), levels = letters)))
## 
## numbOfSampling <- 1E6
## 
## replicate(3,
##              {
##              randWords <- replicate(numbOfSampling,
##                                     paste(sample(letters, mwl, replace = TRUE, prob = letterFreq), collapse = "")
##                                     )
##              intersect(randWords, words)
##              }
## )

