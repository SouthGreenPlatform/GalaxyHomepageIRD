## ----setup, include = FALSE, cache = FALSE-------------------------------
knitr::opts_chunk$set(error = TRUE, collapse = TRUE)

## ------------------------------------------------------------------------
#  a matrix m
m <- matrix(data = 1:20, nrow = 4, byrow = FALSE)
m
m[c(2, 4), ] # return a matrix, two lines, all columns
m[ ,c(2, 4)] # a matrix,, two columns, all lines
m[2:6] # vector-like indexing by column for matrices

## ------------------------------------------------------------------------
idx <- cbind(rows = 1:4, columns = 1:4) # bind two numeric vectors as columns of an idx matrix
m[idx] # indexing returns a vector of values in the diagonal

## ------------------------------------------------------------------------
# Use a logical vector to find rows that have a value > 5 in the second column
# Extract columns two to five for these rows (all columns)
m
m[m[, 2] > 5, 2:4]

## ------------------------------------------------------------------------
row(m)
col(m)

## ------------------------------------------------------------------------
row(m) == col(m) # the diagonal

## ------------------------------------------------------------------------
m[row(m) < col(m)] # extract the upper triangle by column without the diag

## ------------------------------------------------------------------------
# One wants to find values 2, 5 and 10 in `m`:
logiV <- m %in% c(2, 5, 10)
logiV # a logical vector by column
logiM <- matrix(data = logiV, nrow = 4, byrow = FALSE) # coerce into a matrix
logiM
m[logiM] # we did find them, apparently the values have no replicate

# To find the coordinates of the values of interest in the matrix:
idx <- which(logiM, arr.ind = TRUE)

val <- m[idx]

cbind(idx, val = val) # "column" bind the indexing matrix with the vector of values of interest.

## ------------------------------------------------------------------------
t(m)
m + m
m-m

## ----ANS01---------------------------------------------------------------
m <- matrix(data = 1:20, nrow = 4, byrow = FALSE)
diag(m) <- 1
m

## ------------------------------------------------------------------------
measures <- matrix(data = round(runif(n = 96, max = 10), digits = 1), nrow = 8, ncol = 12)

## ----ANS02---------------------------------------------------------------
dummyLogiMat <- matrix(TRUE, nrow = 8, ncol = 12)
head(cbind(which(dummyLogiMat, measures), measure = as.vector(measures)))

## ------------------------------------------------------------------------
fileCabinet <- list(drawer1 = c(length = 1, width = 3),
                    drawer2 = FALSE,
                    top = c(item1 = "flowers", item2 ="sharpener"))
str(fileCabinet)

## ---- eval = FALSE-------------------------------------------------------
## fileCabinet[1:2]
## fileCabinet[c(T, T, F)]
## fileCabinet[c("drawer1", "drawer2")] # Partial name matching is not possible

## ---- eval = FALSE-------------------------------------------------------
## fileCabinet[[3]]
## fileCabinet[["top"]]
## fileCabinet[["t", exact = NA]] # the exact argument controls partial matching, TRUE or NA (return a warning)
## fileCabinet$top
## fileCabinet$t

## ------------------------------------------------------------------------
identical(fileCabinet[1], fileCabinet[[1]])

## ------------------------------------------------------------------------
str(fileCabinet)
fileCabinet[[c(1,2)]]
fileCabinet[[c(3,2)]]
fileCabinet[[c("top", "item2")]]
fileCabinet$top[["item2"]]
fileCabinet$top["item2"]
# Combinations of subsetting operators are possible but not recommended because the code is hard to read:
fileCabinet[[3]][[2]]
fileCabinet[[3]][2]

## ------------------------------------------------------------------------
lst <-  list(a = c(TRUE, FALSE), b = NULL, c = list(list()))
lst[c("a", "c")] <- NULL

## ----ANS03---------------------------------------------------------------
fileCabinet <- list(drawer1 = c(length = 1, width = 3),
                    drawer2 = FALSE,
                    top = c(item1 = "flowers", item2 = "sharpener"))

# Does not work as expected, why?
fileCabinet[2:3] <- c(fileCabinet[1], coins = 1:5)
# Works
fileCabinet[2:3] <- c(fileCabinet[1], list(coins = 1:5))

## ----ANS04---------------------------------------------------------------
fileCabinet[[1:2]] <- 2
fileCabinet$drawer1[2] <- c(WIDTH = 2)

## ------------------------------------------------------------------------
df <- data.frame(A = letters[1:4],
                 `B-2` = rep(c(TRUE, FALSE), each = 2),
                 `C with space` = seq(10, 20, length.out = 4),
                 D = c(runif(3), NA)
)
df

## ------------------------------------------------------------------------
df[c(1,4)] # To select one or several columns. Returns a data frame
df[3]
df[[3]] #To select the CONTENT (class) of a a single column using the list braquets.
df$C
# And so on...

## ------------------------------------------------------------------------
df[,c(1,4)] # extracts columns
df[, c("A", "D")]
df[2:3, ]

## ------------------------------------------------------------------------
df[df$B.2, ] # a df
df[, colnames(df) %in% "D"] # column turned to a vector !!!
df[, colnames(df) %in% "D", drop = FALSE] # column remains a df !!!

df[df$C.with.space < 20 & df$D > 0.4, ] # use comparison and logical operators to subset

## ------------------------------------------------------------------------
with(data = df, df[C.with.space < 20 & D > 0.4, ])

## ------------------------------------------------------------------------
# This works as expected
DF <- data.frame(a = 1:3)
DF$b <- list(1:1, 1:2, 1:3)
str(DF)

## ------------------------------------------------------------------------
# This alternative produce an odd result
DF <- data.frame(a = 1:3, b = list(1:1, 1:2, 1:3))

## ---- eva = FALSE--------------------------------------------------------
DF <- data.frame(a = 1:3, b = I(list(1,1:2,1:3)))

## ------------------------------------------------------------------------
class(df[[3]]) == class(df[3])

## ----ANS05---------------------------------------------------------------
df[, !colnames(df) %in% c("A", "D")] # Option 1
df[, -match(c("A", "D"), colnames(df))] # Option 2
df[c("A", "D")] <- list(NULL) # Option 3
df

## ----ANS06, eval=FALSE---------------------------------------------------
## df[c("A", "D")] <- NULL

## ------------------------------------------------------------------------
df["B.2"] <- NULL
df

## ----ANS07---------------------------------------------------------------
neededPacks <- c("ape", "reshape2", "dplyr", "lattice", "ggplot2", "VennDiagram", "Biostrings")
notInstalled <- neededPacks[!neededPacks %in% rownames(installed.packages())]
notInstalled

installed.packages()[neededPacks, c("Package", "LibPath", "Version")]


## ----ANS08---------------------------------------------------------------
df <- data.frame(A = letters[1:4],
                 `B-2` = rep(c(TRUE, FALSE), each = 2),
                 `C with space` = seq(10, 20, length.out = 4),
                 D = c(runif(3), NA)
)
mean(df$D, na.rm = FALSE)

## ------------------------------------------------------------------------
df <- data.frame(A = letters[1:4],
                 B = rep(c(TRUE, FALSE), each = 2),
                 C = seq(10, 20, length.out = 4),
                 D = c(runif(3), NA)
)

## ---- eval=FALSE---------------------------------------------------------
## subset(x = df, subset = C < 20 & D > 0.4)
## subset(x = df, subset = C < 20 & D > 0.4, select = c("A", "B", "C"))
## subset(x = df, subset = C < 20 & D > 0.4, select = !colnames(df) %in% c("A", "D"))
## subset(x = df, subset = C < 20 & D > 0.4, select = A:C) # "sequence" of column names
## subset(x = df, subset = C < 20 & D > 0.4, select = -(C:D)) # "Negated" column names

## ------------------------------------------------------------------------
colnames(df)
colnames(df) <- month.abb[1:ncol(df)]
rownames(df) <- sample(state.name, size = nrow(df))
df

## ---- echo=FALSE, eval= TRUE---------------------------------------------
df <- data.frame(A = letters[1:4],
                 B = rep(c(TRUE, FALSE), each = 2),
                 C = seq(10, 20, length.out = 4),
                 D = c(runif(3), NA)
)

## ------------------------------------------------------------------------
summary(df)

df[!is.na(df$D), ]

na.omit(df)

## ------------------------------------------------------------------------
df <- df[!is.na(df$D), ] # delete
rbind(df, df[1, ]) # bind
df[nrow(df) + 1, ] <- df[1, ] # bind with another method
df

## ------------------------------------------------------------------------
subset(df, select = A:B) # could be re-assigned to df to delete col C and D
df <- cbind(df, E = state.name[1:nrow(df)], F = rnorm(n = nrow(df))) # does convert to factor
df[ , "G"] <- state.name[1:nrow(df)] # does NOT 
str(df)
df["G"] <- NULL

## ------------------------------------------------------------------------
df <- cbind(df, G = sqrt(df$D)* (df$C + pi)) # calculate values with vectors of equal length
df <- transform(df, H = ceiling(G - mean(C))) # mean(C) is recycled
df

## ------------------------------------------------------------------------
df
df[ order(df$B, df$H, -df$F), ]

## ------------------------------------------------------------------------
df <- subset(df, , A:D)
unique(df)
duplicated(df)
df[duplicated(df), ]
df[-duplicated(df), ]

## ---- echo = FALSE-------------------------------------------------------
products <- data.frame(ProdID = LETTERS[1:4],
                       category = c("vegetable", "meat", "can", "iceCream"),
                       price = 4:1)

sales <- data.frame(CustomID = c("a", "a", "b", "b", "b"),
                    ProdID = c("C", "A", "B", "C", "E"),
                    Date = seq(from = as.Date("2015/9/1"), to = as.Date("2015/9/3"), by = 1)[c(1,1, 2, 3, 3)])

## ------------------------------------------------------------------------
# The grocery store example...
products

sales

## ------------------------------------------------------------------------
bill <- merge(x = sales, y = products, by = "ProdID", all.x = TRUE, sort = FALSE)
bill[order(bill$CustomID, bill$Date, bill$ProdID), ]
# There is no info about product D, what did the cashier!!?

## ------------------------------------------------------------------------
merge(x = sales, y = products, by = "ProdID", all = TRUE, sort = FALSE)
# Product D did not sell well these last days.

## ------------------------------------------------------------------------
cleanBill <- na.omit(bill)
aggregate(x = cleanBill$price, by = cleanBill[c("CustomID", "Date")], FUN = sum)
# That answers our first question

## ------------------------------------------------------------------------
aggregate(. ~ Species, data = iris, FUN = mean)

# The dot in formula means "any columns from data that are otherwise not used"

## ------------------------------------------------------------------------
aggregate(iris[1:4], by = iris["Species"], FUN = cor, method = "spearman")
# cor() complains...

## ------------------------------------------------------------------------
irisCorel <- by(iris[1:4], INDICES = iris["Species"], FUN = cor, method = "spearman")

## ------------------------------------------------------------------------
str(irisCorel)

## ----ANS09---------------------------------------------------------------
mydf <- iris
m <- 3
mydf[ sample(1:nrow(mydf), size = m, replace = FALSE) , ]

## ----ANS10---------------------------------------------------------------
rows <- sort(sample(1:nrow(mydf), size = 2, replace = FALSE))
# Is the sort() necessary?

head(mydf[ rows[1]:rows[2], ])

## ------------------------------------------------------------------------
library(ggplot2)
mySimpleSumy <- aggregate(diamonds, list(diamonds$color), summary)

## ----ANS11, eval= FALSE--------------------------------------------------
## str(mySimpleSumy)

## ----ANS12, eval = FALSE-------------------------------------------------
## mySumy <-aggregate(diamonds, list(diamonds$color), summary, simplify = FALSE)
## str(mySumy)

## ----ANS13---------------------------------------------------------------
library(ggplot2)
myDf <- movies

orderedColIdx <- order(colnames(myDf))

myNewDf <- myDf[orderedColIdx]
head(myNewDf, n = 2)

## ----ANS14---------------------------------------------------------------
myNewDf[ncol(myNewDf)] <- list(NULL)
head(myNewDf, n = 2)

## ----ANS15, eval= FALSE--------------------------------------------------
## library(ggplot2)
## ?movies

## ----ANS16---------------------------------------------------------------
# Visual inspection
# summary(movies)

# Programmatically
colnames(movies)[sapply(movies, function(x) sum(is.na(x))) > 0] ## we'll learn sapply() later

## ----ANS17---------------------------------------------------------------
sum(!is.na(movies$budget))

## ----ANS18---------------------------------------------------------------
sum(movies$rating <= 2.5 | movies$rating > 7.5)

## ----ANS19---------------------------------------------------------------
sum(movies$year ==1980 & movies$rating > 5)

## ----ANS20---------------------------------------------------------------
sum(movies$Action & movies$Animation)

## ----ANS21---------------------------------------------------------------
subset(movies, votes == max(votes) | length == max(length), title:votes)

## ----ANS22---------------------------------------------------------------
movies <- transform(movies, rating_zscore = scale(rating)) # For interactive use
# OR
movies <- cbind(movies, rating_zscore = scale(movies$rating)) # When programming
head(movies, 1)

## ----ANS23---------------------------------------------------------------
moviesGenre <- subset(movies, select = Action:Short)
str(moviesGenre)

## ----ANS24---------------------------------------------------------------
moviesGenreUnique <- aggregate(moviesGenre$Action, by = moviesGenre, FUN = length)

## ----ANS25---------------------------------------------------------------
nrow(moviesGenreUnique)

## ----ANS26---------------------------------------------------------------
moviesGenreUnique[order(moviesGenreUnique$x, decreasing = TRUE)[1:3], ]

## ----ANS27---------------------------------------------------------------
moviesInUniqueGenre <- movies[rowSums(moviesGenre) == 1, , drop = FALSE]

## ----ANS28---------------------------------------------------------------
genreBudget <- subset(moviesInUniqueGenre, !is.na(budget),
                      select = c(budget, rating, Action:Short))

avgBudgetByGenre <- aggregate(. ~ Action + Animation + Comedy + Drama +
                                Documentary + Romance + Short,
          data = genreBudget, FUN = mean)

avgBudgetByGenre[order(-avgBudgetByGenre$budget), ]

## ------------------------------------------------------------------------
color <- c("red", "green", "green", "red", "green", "green", "red")
shape <- c("round", "sharp", "sharp", "round", "round", "sharp", "round")
size <- c("tall", "tall", "small", "tall", "small", "small", "tall")
objects <- data.frame(color, shape, size)

xclass <- xtabs(data = objects)
str(xclass) # a list with other attributes

## ------------------------------------------------------------------------
summary(xclass)

as.data.frame(xclass) # ALL combinations between levels are shown

ftable(xclass) # Another way to flattened cross-classification tables with more than 2 dimensions

## ------------------------------------------------------------------------
# to compute margin sum or other functions
addmargins(xtabs(formula = ~ color + shape, data = objects), FUN = sum)
# to compute proportions (maring = 1, rowwise ; 2, colwise ; not specified, all table)
prop.table(xtabs(formula = ~ color + shape, data = objects))


## ----ANS29---------------------------------------------------------------
library(ggplot2)
ratingCat <- cut(movies$rating, breaks = pretty(movies$rating, 5))
addmargins(table(movies$mpaa, ratingCat), margin = c(1, 2))

## ------------------------------------------------------------------------
magicDrug <- data.frame(Name = rep(LETTERS[1:2], each = 2, times = 2),
                        When = rep(c("before", "after"), times = 4),
                        Speed = c(1, 2, 3, 5, 0, 1, 4, 5),
                        Weight = c(10, 3, 20, 6, 11, 2, 23, 9)
)

## ------------------------------------------------------------------------

library(reshape2)
mdata <- melt(data = magicDrug,
              id.vars = c("Name", "When"), # Specified but unecessary because they're factors
              measure.vars = c("Speed", "Weight"), # Specified but unecessary because they're numerics
              variable.name = "IndPerformances", # What does these variables have in common?
              na.rm = TRUE, # as a reminder for NAs
              value.name = "value") # the default is good
str(mdata)

## ------------------------------------------------------------------------
# again formula specification of the layout
# mean() for aggregation
dcast(data = mdata, formula = IndPerformances ~ When, fun.aggregate = mean)
###  !!! Note that the fun.aggregate function should take a vector of numbers !!! {.build}
###  !!! and return a single summary statistic                                !!! {.build}

## ------------------------------------------------------------------------
dcast(mdata, Name ~ IndPerformances, mean)

## ------------------------------------------------------------------------
dcast(mdata, Name + When ~ IndPerformances, length)

## ------------------------------------------------------------------------
library(reshape2)
summary(iris)

## ----ANS30---------------------------------------------------------------
newIris <- cbind(iris, flowerID = as.character(1:nrow(iris)))

meltedIris <- melt(data = newIris,
                   variable.name = "Object.Dimension",
                   value.name = "Length",
                   actorsAsStrings = FALSE)

meltedIris <-meltedIris[order(meltedIris$Object.Dimension, meltedIris$Length), ]
str(meltedIris)


## ----ANS31---------------------------------------------------------------
varRecodeDf <- cbind(Object.Dimension = levels(meltedIris$Object.Dimension),
                           object = rep(c("sepal", "petal"), each = 2),
                           dimension = rep(c("length", "width"), times = 2)
)

reshapedIris <- subset(merge(varRecodeDf, meltedIris), select = -Object.Dimension)
str(reshapedIris)

## ----ANS32---------------------------------------------------------------
# Melting first:
meltedReshapedIris <- melt(data = reshapedIris)
str(meltedReshapedIris)
dcast(meltedReshapedIris, Species + object ~ dimension, fun.aggregate = mean)

## ----ANS33---------------------------------------------------------------
# casting directly: 
dcast(reshapedIris, Species + object ~ dimension,
      value.var = "Length", fun.aggregate = mean)

## ------------------------------------------------------------------------
dcast(reshapedIris, Species + object + dimension ~ 1,
      value.var = "Length", fun.aggregate = mean)

## ---- message=FALSE------------------------------------------------------
# download the 'flights.csv' file from the dropbox page and save to you curent working dir
library(dplyr)
flights <- tbl_df(read.csv("flights.csv", stringsAsFactors = FALSE))
# or 
# install.packages("hflights")
# library(hflights) ; flights <- hflights

# contains flights that departed from Houston in 2011
glimpse(flights)

## ---- results='hide'-----------------------------------------------------
filter(flights, dest %in% c("SFO", "OAK"))

## ---- results='hide'-----------------------------------------------------
filter(flights, arr_delay > 2 * dep_delay)

## ---- results='hide'-----------------------------------------------------
select(flights, arr_delay:dep_delay)

## ---- results='hide'-----------------------------------------------------
flights <- mutate(flights, speed = dist / (time / 60))
arrange(flights, desc(speed))

## ------------------------------------------------------------------------
flights %>% filter(arr_delay > 2 * dep_delay) %>% select(arr_delay:dep_delay)

## ------------------------------------------------------------------------
flights %>%
    group_by(dest) %>%
    summarise(avg_delay = mean(arr_delay, na.rm=TRUE)) %>%
    arrange(-avg_delay)

## ------------------------------------------------------------------------
flights %>%
    group_by(dest, carrier) %>% 
    mutate(meanTimeByDByC = mean(time, na.rm = TRUE),
           carrierRelativeTime = time / meanTimeByDByC) %>%
    select(dest:carrierRelativeTime)

## ------------------------------------------------------------------------
# determining the correlation between dimensions of flower parts.
aggregate(iris[1:4], by = iris["Species"], FUN = cor, method = "spearman")

# in plyr jargon that translates in:
myCors <- iris %>%
          group_by(Species) %>%
          do(cors = cor(subset(., , Sepal.Length:Petal.Width)))

## ------------------------------------------------------------------------
myCors
str(myCors[1, ])

## ------------------------------------------------------------------------
# Here, do() returns several results joint together in a data frame row
myCors <- iris %>%
          group_by(Species) %>%
          do(data.frame(mpl = mean(.$Petal.Length),
                        msl = mean(.$Sepal.Length),
                        cors = I(list(cor(subset(., , Sepal.Length:Petal.Width))))
                        )
             )

## ------------------------------------------------------------------------
myCors
str(myCors[1, ])

## ----ANS34---------------------------------------------------------------
identical(filter(flights, hour == 0, minute == 0),
          filter(flights, hour == 0 & minute == 0)
)

## ----ANS35---------------------------------------------------------------
flights %>% na.omit() %>%
            group_by(dest) %>%
            summarise(minT = min(time), maxT = max(time), sdS = sd(speed))

## ----ANS36---------------------------------------------------------------
flights %>% filter(dest == "JFK") %>%
            group_by(date) %>%
            summarise(countsToJFK = n())

## ----ANS37---------------------------------------------------------------
flights %>% group_by(carrier) %>%
            arrange(-dep_delay) %>%
            slice(1:3)

## ----ANS38---------------------------------------------------------------
spl1 <- flights %>% filter(dest == "SFO" | dest == "LAX") %>%
            sample_frac(size = 0.3)
spl2 <- flights %>% filter(dest == "SFO" | dest == "LAX") %>%
            sample_frac(size = 0.3)
nrow(intersect(spl1, spl2))
nrow(setdiff(spl1, spl2))
nrow(setdiff(spl2, spl1))

### To illustrate the effect of NSE/ {.build}
## replicate(n, expr) run n times the expression expr and return a list with the results {.build}
weird <- replicate(n = 2, flights %>% filter(dest == "SFO" | dest == "LAX") %>%
            sample_frac(size = 0.3))
weird

