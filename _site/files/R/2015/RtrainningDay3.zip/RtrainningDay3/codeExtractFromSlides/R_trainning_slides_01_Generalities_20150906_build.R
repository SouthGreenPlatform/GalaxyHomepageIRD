## ----setup, include = FALSE, cache = FALSE-------------------------------
knitr::opts_chunk$set(error = TRUE, collapse = TRUE)

## ---- fig.height = 2.5, fig.width = 3------------------------------------
hist(rnorm(1000))

## ---- eval= FALSE--------------------------------------------------------
## 
## 1 + 1
## 
## # 124é"famoi'_(ù*$=+" - Use a hash '#' to add comments that are just ignored
## 
## a <- "hello" # assigning a value to a symbol/name
## A <- 1
## 
## # If you simply enter the variable name or expression at the command prompt,
## # R will PRINT its value.
## a
## A
## 
## 2 <- "error"
## 
## ?Reserved
## 
## B <- 2
## A + B
## 
## C <- c(A, B)
## C

## ---- eval = FALSE-------------------------------------------------------
## mode(C)
## 
## log(x=64, base=4) # reminder about functions and parameters
## log(64, 4)
## 
## # Missing data
## y <- c(1,2,3,NA)
## is.na(y) # returns a vector (F F F T)
## 
## # Not A Number
## sqrt(-9)
## 
## # close your session
## q()

## ---- eval=FALSE---------------------------------------------------------
## # Try and install:
## install.packages(c("ape", "devtools"))

## ---- eval=FALSE---------------------------------------------------------
## source("http://bioconductor.org/biocLite.R") # fetch and execute code of the  function:
## biocLite("packageName")

## ------------------------------------------------------------------------
search() # list of attached R packages and objects
library(ape) # or
library("ape")
search()

## ------------------------------------------------------------------------
session_info() # This function is from devtools but is not loaded
devtools::session_info() # loads devtools if not already done and call session_info()
# run ?"::" if you want.

## ----ANS01, eval = FALSE-------------------------------------------------
## install.packages(c("ape", "reshape2", "dplyr", "lattice", "ggplot2", "VennDiagram"))

## ----ANS02, eval = FALSE-------------------------------------------------
## source("http://bioconductor.org/biocLite.R") # fetch and execute code of the  function:
## biocLite("Biostrings")

## ---- eval=FALSE---------------------------------------------------------
## ?summary

## ---- eval=FALSE---------------------------------------------------------
## ??"\\{"
## ??DNA

## ---- eval=FALSE---------------------------------------------------------
## ?paste

## ---- eval=FALSE---------------------------------------------------------
## ?iris

## ---- eval = FALSE-------------------------------------------------------
## example("paste") # Run the code in the "examples" section of a function doc
## demo("graphics") # some packages offer a demo of their functionalities!

## ------------------------------------------------------------------------
print(sessionInfo(), locale = FALSE)

## ---- eval = FALSE-------------------------------------------------------
## history()

## ---- eval = FALSE-------------------------------------------------------
## savehistory(file = "Rtrainning_20150907.R")

## ---- eval = FALSE-------------------------------------------------------
## getwd()

## ----ANS03, eval = FALSE-------------------------------------------------
## source(file = "sourceMe.R", echo = FALSE)

## ---- eval=FALSE---------------------------------------------------------
## head(iris)

## ---- eval = FALSE-------------------------------------------------------
## installed.packages()
## ls()
## str(iris)
## ls.str()
## rm(A)

## ---- eval=FALSE---------------------------------------------------------
## anticonstitucionalissimamente <- lm(iris)

## ---- eval=FALSE---------------------------------------------------------
## anticonstitucionalissimamente$model$Petal.Width

