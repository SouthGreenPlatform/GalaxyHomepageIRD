## ----setup, include = FALSE, cache = FALSE-------------------------------
knitr::opts_chunk$set(error = TRUE, collapse = TRUE)

## ---- eval = FALSE-------------------------------------------------------
## if (condition) true_expression
## 
## if (condition) true_expression else false_expression
## 
## if (condition) {
##     true_expression
## } else {
##     false_expression
## }
## 
## if (condition) true_expression else if (condition) true_expression else false_expression

## ------------------------------------------------------------------------
if (FALSE) "this will not be printed" else "this will be printed"

x <- 3
if (is(x, "numeric")) x/2 else print("x is not numeric")

# The condition statement should be logical and of length one
if (1:3 < 2:4) "It works but will be discussed later"

# For compact assignement
y <- if(x == 2) x else x + 1

## ------------------------------------------------------------------------
if (y < 0) {
   print("Negative number")
} else if (y > 0) {
   print("Positive number")
} else
   print("Zero")

## ------------------------------------------------------------------------
a = c(5,7,2,9)
ifelse(a %% 2 == 0,"even","odd") # yes annd no are recycled

## ------------------------------------------------------------------------
x <- c(4:-3)
sqrt(x)  #- gives warnings!
recodedX <- ifelse(x >= 0, x, NA)
sqrt(recodedX)  # no warning

## ------------------------------------------------------------------------
x[x < 0] <- NA
sqrt(x)

## ------------------------------------------------------------------------
s <- c("My", "first", "for", "loop")
for (value in s) {
  print(value)
}

## ------------------------------------------------------------------------
i <- 3
s <- c("My", "first", "for", "loop")
for (i in seq_along(s)) print(s[i])

## ------------------------------------------------------------------------
mymat = matrix(nrow = 10, ncol = 10) # create a 10 x 10 matrix (of 10 rows and 10 columns)

for(i in 1:dim(mymat)[1]) {      # for each row
  for(j in 1:dim(mymat)[2]) {    # for each column
    mymat[i,j] = i*j             # assign values based on position: product of two indexes
  }
}
head(mymat)


## ------------------------------------------------------------------------
mymat2 <- outer(1:10, 1:10, FUN = `*`)
identical(mymat, mymat2)


## ------------------------------------------------------------------------
i <- 6
while (i < 10) { i = i + 1; print(i) ; }

## ------------------------------------------------------------------------
repeat {
  print(i) ; i = i + 1
  if (i >= 13) break
}

## ------------------------------------------------------------------------
i <- 6
while (i < 10) {
  i = i + 1
  if (identical(i, 8)) next
  print(i)
}
  

## ------------------------------------------------------------------------
if(1 != NULL) cat("Too Bad!")
if(!identical(1, NULL)) cat("Too Bad!")

1 == as.integer(1)
identical(1, as.integer(1)) # stored as different types
1L == as.integer(1) 
typeof(1)
typeof(1L)

## ----ANS01---------------------------------------------------------------
b <- seq(1, by = pi, length.out = 4) # create b
b

a <- numeric(0)
for (i in 1:length(b)) { a[i] = cos(b[i]) }
a

a <- cos(b) # this is the trick!
a

## ------------------------------------------------------------------------
set.seed(123)
for (i in 1:10) {
  x <- runif(1, max = 10)
  if (x > 5) y[i] <- factorial(as.integer(x))
  else y[i] <- x }
y

## ----ANS02---------------------------------------------------------------
set.seed(123)
x <- runif(10, max = 10) # generating all necessary x values
z <- ifelse(x>5, factorial(as.integer(x)), x) # substitute 'if' in the loop for ifelse()
identical(y, z) # check that this is indeed the same

## ----ANS04---------------------------------------------------------------
do.it <- function(p, q){
  if(p > 0){
    return(q/p);
  } else {
    return(p/q);
  }
}

## ------------------------------------------------------------------------
d <- cbind(x = round(runif(n = 4, min = -5, max = 5)),
            y = round(runif(n = 4, min = -2, max = 2)))
t(d) # print the transposed matrix because of space constraints

## ----ANS05---------------------------------------------------------------
r <- numeric(0)
for(i in 1:nrow(d)){
  r[i] <- do.it(d[i, "x"], d[i, "y"])
}
r

## ------------------------------------------------------------------------
lst <- replicate(5, rnorm(sample(1:50, 1)), simplify = FALSE)

## ------------------------------------------------------------------------
# preallocate an empty list of the proper length to save computing time
out <- vector("list", length(lst))
# here is the loop:
for (i in seq_along(lst)) {
  out[[i]] <- length(lst[[i]]) # assign value to an element of out
}
unlist(out) # simplify to a vector rather than a list

## ------------------------------------------------------------------------
unlist(lapply(X = lst, FUN = length))

## ---- eval= FALSE--------------------------------------------------------
## lapply(X = lst, FUN = quantile)

## ---- eval= FALSE--------------------------------------------------------
## lapply(X = lst, FUN = quantile, probs = seq(0, 1, 0.50))
## # or alternatively:
## lapply(X = lst, FUN = function(vect) quantile(vect, probs = seq(0, 1, 0.50)))

## ---- eval= FALSE--------------------------------------------------------
## lapply(X = lst, FUN = function(vect) {
##   quants <- quantile(vect, probs = seq(0, 1, 0.50))
##   count <- c(n = length(vect))
##   return(c(count, quants))
##   }
## )

## ---- eval= TRUE, echo= FALSE--------------------------------------------
sapply(X = lst, FUN = function(vect) {
  quants <- quantile(vect, probs = seq(0, 1, 0.50))
  count <- c(n = length(vect))
  return(c(count, quants))
  }
)

## ---- eval= TRUE, echo= TRUE---------------------------------------------
mat <- sapply(X = lst, FUN = function(vect) {
  quants <- quantile(vect, probs = seq(0, 1, 0.50))
  count <- c(n = length(vect))
  sd <- c(sd = sd(vect))
  return(c(count, sd, quants))
  }
)
t(mat)

## ------------------------------------------------------------------------
a <- matrix(1:20, nrow = 5)
a
apply(X = a, MARGIN = 1, FUN = mean) # by rows
apply(a, 2, mean) # by columns

## ------------------------------------------------------------------------
m <- matrix(c(seq(from = -23, to = 25, by = 2)), nrow = 5, ncol = 5)
m

## ------------------------------------------------------------------------
apply(m, MARGIN = c(1,2), function(x) x%%10) # One option
m%%10 # is another one

## ------------------------------------------------------------------------
system.time(for (i in 1:10000) apply(m, MARGIN = c(1,2), function(x) x%%10))
system.time(for (i in 1:10000) m%%10)


## ------------------------------------------------------------------------
# First compute the means of the columns
mtmeans <- lapply(mtcars, mean)

# Then divide each elements of the columns by the corresponding mean of the column
mtWeightedMeans <- mapply(`/`, mtcars, mtmeans, SIMPLIFY = TRUE)

## ---- eval = FALSE, echo = FALSE-----------------------------------------
## mtWeightedMeans <- mapply(`/`, mtcars, mtmeans, SIMPLIFY = FALSE, USE.NAMES = FALSE)

## ------------------------------------------------------------------------
mapply(rep, 1:3, 3:1)
mapply(rep, times = 1:3, x = 3:1)

## ----ANS07---------------------------------------------------------------
MyCumsumWithFor <- function(v) {
  cumSumRes <- rep(v[1], length(v)) # first create 
  for (i in 2:length(v)) {cumSumRes[i] <- cumSumRes[i-1] + v[i]}
  cumSumRes
}
v <- as.numeric(1:5)
MyCumsumWithFor(v)

## ----ANS08---------------------------------------------------------------
MyCumsumWithFor <- function(v) {
  if(!is.numeric(v)) v <- as.numeric(v)
  cumSumRes <- rep(v[1], length(v)) # first create 
  for (i in 2:length(v)) {cumSumRes[i] <- cumSumRes[i-1] + v[i]}
  cumSumRes
}
v <- 1:5
MyCumsumWithFor(v)

## ----ANS09---------------------------------------------------------------
MyCumsumWithSapply <- function(v) {
  if(!is.numeric(v)) v <- as.numeric(v)
  cumSumRes <- rep(v[1], length(v))
  sapply(2:length(v), function(i) cumSumRes[i] <<- cumSumRes[i-1] + v[i])
  cumSumRes
}

identical(MyCumsumWithSapply(v), MyCumsumWithFor(v))

## ----ANS10---------------------------------------------------------------
identical(cumsum(v), MyCumsumWithFor(v))

v <- 1:1e5

system.time(MyCumsumWithFor(v))
system.time(MyCumsumWithSapply(v))
system.time(cumsum(v))

## ----ANS11---------------------------------------------------------------
boots <- lapply(1:10, function(i) {
  rows <- sample(1:nrow(quakes), rep = TRUE)
  quakes[rows, ]
})

## ----ANS12---------------------------------------------------------------
BootstrapIt <- function(df, n = 10) {
  boots <- lapply(1:n, function(i) {
    rows <- sample(1:nrow(df), rep = TRUE)
    df[rows, ]
  })
  return(boots)
}

mySample <- BootstrapIt(airquality, n = 2)

## ----ANS13---------------------------------------------------------------
library(ggplot2)
# select only columns of numeric type
diamondsNum <- diamonds[, sapply(diamonds, is.numeric)]

meansByCutBy <- by(diamondsNum, diamonds$cut, function(x) sapply(x, mean))

# are you familiar with this:
meansByCutBy <- do.call(rbind, meansByCutBy)
meansByCutBy

## ----ANS14---------------------------------------------------------------
meansByCutAg <-aggregate(diamondsNum, list(diamonds$cut), mean)
meansByCutAg

