
## I Introduction à \code{Sweave} et \pkg{knitr}

library(knitr)
knit("doc1.Rmd")

## II Structure des données

1/0
10^1000 # overflow
exp(-1/0)

## III Introduction à la programmation orientée objet

print # == print(print)
methods(str)
length(methods(print))
library(ape)
as.DNAbin
as.phylo
methods(class = "phylo")
methods(class = "multiPhylo")
library(pegas)
data(woodmouse)
h <- haplotype(woodmouse)
class(h)
methods(class = "haplotype")
methods(class = "DNAbin")

## IV Graphiques

length(par())
par(c("mar", "oma"))

## V Modèles linéaires

x <- 1:(n <- 100)
y <- x + 3 + rnorm(n, 0, 10)
mod <- lm(y ~ x)
summary(mod)
plot(x, y)
abline(mod)
abline(b = 1, a = 3, lty = 2)
legend("topleft", legend = c("Modèle estimé",
                "Modèle simulé"), lty = 1:2)
yb <- rnorm(60, 1:3)
z <- gl(3, 1, 60)
mod.b <- lm(yb ~ z)
summary(mod.b)
plot(z, yb)
plot.default(z, yb)
library(lattice)
histogram(~ yb | z, layout = c(1, 3))
apropos("^contr\\.")
contr.treatment(gl(3, 1)) # défaut dans R
contr.SAS(gl(3, 1))
summary(aov(yb ~ z))
model.matrix(yb ~ z)
data.frame(model.matrix(yb ~ z), z)
plot(y, fitted(mod))
abline(a = 0, b = 1, lty = 3)
hist(residuals(mod))\pause
par(mfcol = c(2, 2))
plot(mod)
mod.new <- lm(c(y, 75) ~ c(x, 100))
plot(mod.new)
a <- "http://www.esapubs.org/Archive/ecol/E084/093/"
b <- "Mammal_lifehistories_v2.txt"
f <- paste0(a, b)
LIFEHIST <- read.delim(f, na.string = c("-999", "-999.00"))\pause
m1 <- lm(litter.size ~ mass.g., data = LIFEHIST)\pause
summary(m1)
m2 <- lm(litter.size ~ order, data = LIFEHIST)
# m2 <- update(m1, formula = litter.size ~ order)\pause
summary(m2)
anova(m2) # == summary(aov(litter.size ~ order ...
m3 <- lm(litter.size ~ mass.g.*order, data = LIFEHIST)\pause
summary(m3)
anova(m3)
anova(lm(litter.size ~ order*mass.g., data = LIFEHIST))
drop1(m3, test = "F")
drop1(lm(litter.size~order+mass.g., data=LIFEHIST), test="F")
library(lattice)
xyplot(litter.size ~ log(mass.g.) | order, data = LIFEHIST)
predict(m1, newdata = 1e9)
predict(m1, newdata = data.frame(mass.g. = 1e9))
ndf <- data.frame(mass.g. = 1e9)
predict(m1, newdata = ndf)

## VI Maximum de vraisemblance

x <- rnorm(10)
prod(dnorm(x))
prod(dnorm(x, -1))
prod(dnorm(x, 1))
prod(dnorm(rnorm(600)))
sum(dnorm(x, log = TRUE))
sum(dnorm(x, -1, log = TRUE))
sum(dnorm(x, 1, log = TRUE))
m <- seq(-1, 1, 0.1)
## l <- numeric(length(m))
## for (i in 1:length(l))
##   l[i] <- sum(dnorm(x, m[i], log = TRUE))
l <- sapply(m,
 function(y) sum(dnorm(x, y, log = TRUE)))
plot(m, l)
fd <- function(p) -2*sum(dnorm(x, p, log = TRUE))
nlm(fd, 1)
mean(x) # rassurant, non ?
out <- nlm(fd, 1, hessian = TRUE)
se <- solve(diag(out$hessian))
## intervalle de confiance a 95%:
out$estimate - 1.96*se
out$estimate + 1.96*se
x1 <- rnorm(10)
x2 <- rnorm(10, 1)
## modèle nul (k = 1):
x <- c(x1, x2)
nlm(fd, 1)
## modèle alternatif (k = 2):
x <- x1
nlm(fd, 1)
x <- x2
nlm(fd, 1)
(chi <- 61.29482 - (23.92164 + 27.00276))
1 - pchisq(chi, 2)
61.29482 + 2*1
23.92164 + 27.00276 + 2*2
x <- 1:50
y <- 1.5*x + 8 + rnorm(50, 0, 10)
nlm(fd, c(1, 1, 1))
lm(y ~ x)$coeff
summary(lm(y ~ x))$sigma
AIC(lm(y ~ x))

## VII Modèles linéaires généralisés

gm1 <- glm(litter.size ~ mass.g., data = LIFEHIST)
summary(gm1)
anova(gm1, test = "Chisq")
args(gaussian)
gm1inv <- glm(litter.size ~ mass.g., gaussian("inverse"),
              data = LIFEHIST)
summary(gm1inv)
x <- runif(50)
y <- rpois(50, x)
plot(x, y)
gm4 <- glm(y ~ x)
gm5 <- glm(y ~ x, poisson)
summary(gm4)
summary(gm5)
y <- sample(0:1, size = 20, replace = TRUE)
x <- 1:20
gmb1 <- glm(y ~ x, binomial)
gmb2 <- glm(cbind(y, 1 - y) ~ x, binomial)
c(AIC(gmb1), AIC(gmb2))
glm(!y ~ x, binomial)
glm(cbind(1 - y, y) ~ x, binomial)
Y <- cbind(y, 1 - y)
glm(Y ~ x, binomial)
glm(Y[, 2:1] ~ x, binomial)
library(MASS)
data(Aids2)
?Aids2
aids.m1 <- glm(status ~ sex, binomial, data = Aids2)
anova(aids.m1, test = "Chisq")
aids.m2 <- glm(status ~ age, binomial, data = Aids2)
anova(aids.m2, test = "Chisq")
aids.m3 <- glm(status ~ age*sex, binomial, data = Aids2)
anova(aids.m3, test = "Chisq")
summary(aids.m2)
range(Aids2$age)
a <- seq(0, 82, 0.1)
risk <- predict(aids.m2, newdata = data.frame(age = a),
                type = "response")
plot(a, risk, type = "l", xlab = "Âge (années)",
     ylab = "Probabilité de décès", ylim = 0:1)
title("Risque de mortalité prédit par le modèle \"aids.m2\"")
Aids2$surv <- Aids2$death - Aids2$diag
surv.m1 <- glm(surv ~ age, Gamma, data = Aids2,
               subset = surv > 0)
anova(surv.m1, test = "Chisq")
summary(surv.m1)
summary(glm(status ~ age, quasibinomial, data = Aids2))
anova(eagles.glm, test = "Chisq")
summary(eagles.glm)
summary(glm(cbind(y, n - y) ~ P*A + V, quasibinomial,
    data = eagles))
summary(glm(cbind(y, n - y) ~ P*A, quasibinomial,
     data = eagles))
