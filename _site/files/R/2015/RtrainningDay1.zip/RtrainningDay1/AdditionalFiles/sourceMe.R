
x <- rnorm(1000)

cat("\n#####################################\n")
cat("This will generate 1000 random numbers from a normal distribution and display",
    "their distribution on a histogram.\n", sep = " ", fill = 45)
cat("The mean of the sample is ", mean(x), " and standard distribution is ", sd(x), ".\n", sep = "", fill = 45)
cat("\n#####################################\n")


hist(x)