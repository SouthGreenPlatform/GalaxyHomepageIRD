#!/usr/bin/env Rscript

allArgs <- commandArgs()
userArgs <- commandArgs(TRUE)


cat("The complete arguments were:\n")
cat(allArgs,"\n")
cat("!!!!!!!!!!!!!!!!!!!!!!!\n\n")
cat("The user supplied arguments were:\n")
cat(userArgs,"\n")
cat("!!!!!!!!!!!!!!!!!!!!!!!\n\n")
cat("The second user supplied argument was:\n")
cat(userArgs[2],"\n")
cat("!!!!!!!!!!!!!!!!!!!!!!!\n\n")

